#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double OrionVersionNumber;
FOUNDATION_EXPORT const unsigned char OrionVersionString[];

#import "Orion-Target.h"
#import "orion_public.h"
